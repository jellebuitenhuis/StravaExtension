# Strava Ranks Chrome Extension

Because Strava removed some options from segments, but still sends the data in their API requests, I've decided to show that data again. 

### Features:
  * You can now sort the table containing your segments, just click on the relevant table header
  * On each segment you can see your personal rank, the total amount of attempts, and the percentile of your best attempt
  * You can see all attempts you made on a segment
  * The analyse button on the activity page now works
  * The analyse button on a bike segment now brings you to the analysis page with the segment selected